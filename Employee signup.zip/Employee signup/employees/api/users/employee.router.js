const router = require("express").Router();
const { checkToken } = require("../../auth/token_validation");
const {
  createEmployee,
  login,
  getEmployeeById,
  getEmployees,
  updateEmployee,
  deleteEmployee,
 
} = require("./employee.controller");
router.get("/getAllEmployees", checkToken, getEmployees);
router.post("/createEmployee",  createEmployee);
router.get("/getEmployeeById/:id", checkToken, getEmployeeById);
router.post("/login", login);
router.patch("/updateEmployee", checkToken, updateEmployee);
router.delete("/deleteEmployee/:id", checkToken, deleteEmployee);

module.exports = router