const pool = require("../../config/database");

module.exports = {
  create: (data, callBack) => {
    pool.query(
      `insert into registration(firstname, lastname,  email, password,date_of_birth,address ,phone_no) 
                values(?,?,?,?,?,?,?)`,
      [
        data.firstname,
        data.lastname,
        data.email,
        data.password,
        data.date_of_birth,
        data.address,
        data.phone_no
      ],
      (error, results, fields) => {
        if (error) {
          callBack(error);
        }
        return callBack(null, results);
      }
    );
  },
  getEmployeeByUserEmail: (email, callBack) => {
    pool.query(
      `select * from registration where email = ?`,
      [email],
      (error, results, fields) => {
        if (error) {
          callBack(error);
        }
        return callBack(null, results[0]);
      }
    );
  },
  getEmployeeByUserId: (id, callBack) => {
    pool.query(
      `select id,firstname,lastname,email,password,date_of_birth,address, phone_no from registration where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          callBack(error);
        }
        return callBack(null, results[0]);
      }
    );
  },
  getEmployees: callBack => {
    pool.query(
      `select id,firstname,lastname,email,password,date_of_birth,address,phone_no from registration`,
      [],
      (error, results, fields) => {
        if (error) {
          callBack(error);
        }
        return callBack(null, results);
      }
    );
  },
  updateEmployee: (data, callBack) => {
    pool.query(
      `update registration set firstname=?, lastname=?,  email=?, password=?,date_of_birth=?,address=?, phone_no=? where id = ?`,
      [
        data.firstname,
        data.lastname,
        data.email,
        data.password,
        data.date_of_birth,
        data.address,
        data.phone_no,
        data.id
      ],
      (error, results, fields) => {
        if (error) {
          callBack(error);
        }
        return callBack(null, results);
      }
    );
  },
  deleteEmployee: (id, callBack) => {
    pool.query(
      `delete from registration where id = ?`,
      [id],
      (error, results, fields) => {
        if (error) {
          callBack(error);
        }
        return callBack(null, results[0]);
      }
    );
  }
};