const {
    create,
    getEmployeeByUserEmail,
    getEmployeeByUserId,
    getEmployees,
    updateEmployee,
    deleteEmployee
  } = require("./employee.service");
  const { hashSync, genSaltSync, compareSync } = require("bcrypt");
  const { sign } = require("jsonwebtoken");
  
  module.exports = {
    createEmployee: (req, res) => {
      const body = req.body;
      const salt = genSaltSync(10);
      body.password = hashSync(body.password, salt);
      create(body, (err, results) => {
        if (err) {
          console.log(err);
          return res.status(500).json({
            success: 0,
            message: "Database connection errror"
          });
        }
        return res.status(200).json({
          success: 1,
          message:"user created successfully",
          data: results
        });
      });
    },
    login: (req, res) => {
      const body = req.body;
      getEmployeeByUserEmail(body.email, (err, results) => {
        if (err) {
          console.log(err);
        }
        if (!results) {
          return res.json({
            success: 0,
            data: "Invalid email or password"
          });
        }
        const result = compareSync(body.password, results.password);
        if (result) {
          results.password = undefined;
          const jsontoken = sign({ result: results }, "qwe1234", {
            expiresIn: "1h"
          });
          return res.json({
            success: 1,
            message: "login successfully",
            token: jsontoken
          });
        } else {
          return res.json({
            success: 0,
            data: "Invalid email or password"
          });
        }
      });
    },
    getEmployeeById: (req, res) => {
      const id = req.params.id;
      getEmployeeByUserId(id, (err, results) => {
        if (err) {
          console.log(err);
          return;
        }
        if (!results) {
          return res.json({
            success: 0,
            message: "Record not Found"
          });
        }
        results.password = undefined;
        return res.json({
          success: 1,
          message: "Employee successfully Retreived by ID",
          data: results
        });
      });
    },
    getEmployees: (req, res) => {
      getEmployees((err, results) => {
        if (err) {
          console.log(err);
          return;
        }
        return res.json({
          success: 1,
          message: "All employees successfully retreived",
          data: results
        });
      });
    },
    updateEmployee: (req, res) => {
      const body = req.body;
      const salt = genSaltSync(10);
      body.password = hashSync(body.password, salt);
      updateEmployee(body, (err, results) => {
        if (err) {
          console.log(err);
          return;
        }
        if(!results){
          return res.json({
            success:0,
            message:"failed to update user"
          });
        }
        return res.json({
          success: 1,
          message: "updated successfully"
        });
      });
    },
    deleteEmployee: (req, res) => {
      const id = req.params.id;
      
      deleteEmployee(id, (err, results) => {
        if (err) {
          console.log(err);
          return;
        }
        if (!results) {
          return res.json({
            status:404,
            success: 0,
            message: "Record Not Found"
          });
        }
        return res.json({
          success: 1,
          message: "employee deleted successfully"
        });
      });
    }
  };