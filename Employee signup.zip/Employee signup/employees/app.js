const express=require('express')
const app=express();
require('dotenv').config();
const userRouter = require("./api/users/employee.router");
const swaggerUI= require('swagger-ui-express')

const swaggerDocument= require('./openapi.json')

app.use(express.json());

app.use("/", userRouter);
app.use('/swagger',swaggerUI.serve, swaggerUI.setup(swaggerDocument));
const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log("server up and running on PORT :", port);
});
